
osc.mem <- function(dfxy, z, fwd, mem_selection, color = "seagreen4", ncol = 2) {

  require(tidyverse)
  require(cowplot)

  plots <- vector("list", length(mem_selection))

  for (i in 1:length(mem_selection)) {
    plots[[i]] <- ggplot(data = data.frame(x = (1:length(dfxy[, 1])),
                                           y = z[, sort(fwd$order)[i]]),
                         aes(x = x, y = y)) +
      geom_abline(intercept = 0, slope = 0, linetype = "dashed", color = "aquamarine4") +
      geom_line(linewidth = 1, color = color) +
      labs(y = paste("dbMEM", sort(fwd$order)[i]), x = "Coordonnée X") +
      theme_bw() +
      theme(
        panel.background = element_rect(fill = 'transparent'),
        plot.background = element_rect(fill = 'transparent', color = NA),
        legend.background = element_rect(fill = 'transparent'),
        legend.box.background = element_rect(fill = 'transparent')
      )
  }

  plot_grid(plotlist = plots, ncol = ncol)
}
